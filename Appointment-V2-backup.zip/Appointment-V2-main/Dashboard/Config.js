const CONFIG_URL = 'https://script.google.com/macros/s/AKfycby5d70JIX4aaFB0-YrsN06mjQFWQMHTYxphk6o_VDDpweah_lhAu61qHLQZyJ1v0QJm/exec';
const WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbw-Yjv94ffGn98tweURPh1cxDfegwcffZg8dZ_YsZDqwxi2L4G6Q_hIETG1Wv5IMP3V/exec';
const DETAILS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbw-Yjv94ffGn98tweURPh1cxDfegwcffZg8dZ_YsZDqwxi2L4G6Q_hIETG1Wv5IMP3V/exec';

const LIFF_ID = '2007432636-DpowZgEb'; // Booking
const LIFF_ID_HIS = '2007432636-ROyNVwOA'; // History
